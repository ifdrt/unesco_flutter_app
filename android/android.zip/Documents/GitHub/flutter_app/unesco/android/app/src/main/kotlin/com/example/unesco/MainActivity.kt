package com.example.unesco

import android.app.Activity
import androidx.annotation.NonNull
import androidx.mediarouter.app.MediaRouteChooserDialog
import androidx.mediarouter.app.MediaRouteControllerDialog
import com.google.android.gms.cast.framework.CastContext
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.PluginRegistry

class MainActivity: FlutterActivity() {
    private  var CHANNEL="samples.flutter.dev/battery"
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)




        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)

        ch.setMethodCallHandler { call, result ->

            when (call.method) {
//
                "print" -> {
val castsession = CastContext.getSharedInstance()?.sessionManager?.currentCastSession
                    if (castsession!=null){
                        val dialogc = MediaRouteControllerDialog(activity,R.style.CastExpandedController)
                        dialogc.mediaControlView.showContextMenu()
                    }else{
                        val dialogc = MediaRouteChooserDialog(activity,R.style.CastExpandedController)
                        dialogc.routeSelector =CastContext.getSharedInstance()?.mergedSelector!!
                    }

                    result.success("android channel workß")

                };








            }
        }

    }


}


