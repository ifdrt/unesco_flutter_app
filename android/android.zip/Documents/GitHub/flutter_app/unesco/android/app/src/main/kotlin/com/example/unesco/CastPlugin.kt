package com.example.unesco

import android.app.Activity
import com.google.android.gms.cast.framework.CastContext
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.PluginRegistry

class CastPlugin (private  val activity: Activity,private  val methch:MethodChannel) {
    companion object {

        fun registerwith(register: PluginRegistry.Registrar) {
           // CastContext.getSharedInstance(activity)
        }
    }


}
